<?php

include 'koneksi.php';

$result = array();
$query = mysqli_query($con, "SELECT * FROM tb_lapor");

while($row = mysqli_fetch_assoc($query)){
    $result[] = $row;
}

echo json_encode(array('result'=>$result), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_HEX_APOS);

?>