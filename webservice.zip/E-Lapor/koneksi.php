<?php

$namaserver = "localhost";
$username = "root";
$password = "";
$database = "e-lapor";

$con = mysqli_connect($namaserver, $username, $password, $database);

if(!$con){
    die("koneksi gagal: " .mysqli_connect_error());
}

?>
