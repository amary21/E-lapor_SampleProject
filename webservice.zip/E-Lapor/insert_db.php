<?php

include 'koneksi.php';

$upload_path = 'image/';
$server_ip = gethostbyname(gethostname());
$upload_url = 'http://'.$server_ip.'/E-Lapor/'.$upload_path;

$nama = $_POST['nama'];
$judul = $_POST['judul'];
$isi = $_POST['isi'];
$latitude = $_POST['latitude'];
$longitude = $_POST['longitude'];
$kategori = $_POST['kategori'];


$fileinfo = pathinfo($_FILES['image']['name']);
$extension = $fileinfo['extension'];
$file_url = $upload_url.'IMG_'.date("Y-m-d").'_'.rand(0,1000).'.'.$extension;
$file_path = $upload_path.'IMG_'.date("Y-m-d").'_'.rand(0,1000).'.'.$extension;


if(!$nama || !$judul || !$isi || !$latitude || !$longitude || !$kategori){
    $message_error["message"] = "lengkapi data...";
    $jsonfile = json_encode($message_error, JSON_PRETTY_PRINT);
    echo $jsonfile;
}else{

    move_uploaded_file($_FILES['image']['tmp_name'],$file_path);
    
    $query = "INSERT INTO tb_lapor (id, nama, judul, isi, foto, latitude, longitude, kategori, waktu, status) 
                VALUES (NULL, '$nama', '$judul', '$isi', '$file_url', '$latitude', '$longitude', '$kategori', current_timestamp(), 'lapor')";
    $insert = mysqli_query($con, $query);

    if($insert){
        $message_success["message"] = "data succesfull added";
        $jsonfile = json_encode($message_success, JSON_PRETTY_PRINT);
        echo $jsonfile;
    }else{
        $message_error['message'] = "data gagal tersimpan";
        $jsonfile = json_encode($message_error, JSON_PRETTY_PRINT);
        echo $jsonfile;
    }
}

?>