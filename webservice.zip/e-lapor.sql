-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 05, 2020 at 10:49 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e-lapor`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_lapor`
--

CREATE TABLE `tb_lapor` (
  `id` int(15) NOT NULL,
  `nama` varchar(30) DEFAULT NULL,
  `judul` varchar(30) DEFAULT NULL,
  `isi` varchar(500) DEFAULT NULL,
  `foto` varchar(250) DEFAULT NULL,
  `latitude` varchar(15) DEFAULT NULL,
  `longitude` varchar(15) DEFAULT NULL,
  `kategori` varchar(15) DEFAULT NULL,
  `waktu` timestamp NULL DEFAULT current_timestamp(),
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_lapor`
--

INSERT INTO `tb_lapor` (`id`, `nama`, `judul`, `isi`, `foto`, `latitude`, `longitude`, `kategori`, `waktu`, `status`) VALUES
(19, 'test', 'kecelakaan', 'kecelakaan', 'http://127.0.1.1/E-Lapor/image/IMG_2020-01-04.jpg', '102', '73', 'lalu lintas', '2020-01-04 10:16:17', 'lapor'),
(20, 'test', 'kecelakaan', 'kecelakaan', 'http://127.0.1.1/E-Lapor/image/IMG_2020-01-04.jpg', '102', '73', 'lalu lintas', '2020-01-04 10:16:34', 'lapor'),
(21, 'test1', 'kecelakaan', 'kecelakaan', 'http://127.0.1.1/E-Lapor/image/IMG_2020-01-04.jpg', '102', '73', 'lalu lintas', '2020-01-04 10:16:41', 'lapor'),
(22, 'test1', 'kecelakaan', 'kecelakaan', 'http://127.0.1.1/E-Lapor/image/IMG_2020-01-04.png', '102', '73', 'lalu lintas', '2020-01-04 10:17:37', 'lapor'),
(23, 'test1', 'kecelakaan', 'kecelakaan', 'http://127.0.1.1/E-Lapor/image/IMG_2020-01-04_348.png', '102', '73', 'lalu lintas', '2020-01-04 10:20:09', 'lapor'),
(24, 'test1', 'kecelakaan', 'kecelakaan', 'http://127.0.1.1/E-Lapor/image/IMG_2020-01-04_595.png', '102', '73', 'lalu lintas', '2020-01-04 10:20:15', 'lapor'),
(25, 'test1', 'kecelakaan', 'kecelakaan', 'http://127.0.1.1/E-Lapor/image/IMG_2020-01-04_757.png', '102', '73', 'lalu lintas', '2020-01-04 10:21:11', 'lapor'),
(26, 'test1', 'kecelakaan', 'kecelakaan', 'http://127.0.1.1/E-Lapor/image/IMG_2020-01-04_982.png', '102', '73', 'lalu lintas', '2020-01-04 10:21:14', 'lapor'),
(27, 'test1', 'kecelakaan', 'kecelakaan', 'http://127.0.1.1/E-Lapor/image/IMG_2020-01-04_994.png', '102', '73', 'lalu lintas', '2020-01-04 10:21:20', 'lapor'),
(28, 'test1', 'kecelakaan', 'kecelakaan', 'http://127.0.1.1/E-Lapor/image/IMG_2020-01-04_632.png', '102', '73', 'lalu lintas', '2020-01-04 10:21:21', 'lapor'),
(29, 'test1', 'kecelakaan', 'kecelakaan', 'http://127.0.1.1/E-Lapor/image/IMG_2020-01-05_944.png', '102', '73', 'lalu lintas', '2020-01-05 01:19:44', 'lapor');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_lapor`
--
ALTER TABLE `tb_lapor`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_lapor`
--
ALTER TABLE `tb_lapor`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
